# Matchy — Front-end-only tutor UI

This is a static, multi-page front-end redesign of the uploaded Personalized Tutor App using the visual language of the uploaded Matchy `index.html`.

## Theme carried over
- Background: `#FAFAF5`
- Ink: `#121615`
- Purple brand: `#712BF7`
- Lime accent: `#A9DF02`
- Muted text: `#5B5F66`
- Border: `#DEDFD6`
- Typography: Bricolage Grotesque + DM Sans
- Soft lime/purple radial gradients and rounded cards
- Matchy logo used throughout

## Pages
- `index.html` — Home / dashboard
- `tutor.html` — Socratic tutor demo
- `community.html`
- `match.html`
- `discover.html`
- `spaces.html`
- `friends.html`
- `messages.html`
- `library.html`
- `profile.html`
- `settings.html`

## Backend
There is intentionally no backend, API, authentication, database, or server-side code. Demo interactions use JavaScript and `localStorage` only. The tutor replies are predefined front-end demo responses, not a live AI service.

Open `index.html` directly in a browser, or serve this folder with any static file server.
