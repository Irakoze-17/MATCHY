MATCHY INTEGRATED WEBSITE

Start at index.html. It contains the updated Matchy login/signup interface and redirects successful login/signup flows to home.html. login.html is also kept as an alias for compatibility. The remaining existing project pages and shared styling are retained with the new teal, pink, cream, and dark green branding.

Open index.html in a modern browser to preview. Authentication remains frontend-only until connected to the backend.
