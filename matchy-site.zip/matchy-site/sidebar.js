// ===== Matchy — shared sidebar =====
// Injects the app shell's sidebar nav into any page that includes a
// <div id="sidebarMount"></div>. Demo-only (no backend) — just highlights
// the active page and shows a fixed placeholder user.

(function(){
  const NAV = [
    { href:'home.html',      label:'Home',       icon:'M3 11l9-8 9 8M5 10v10h14V10' },
    { href:'match.html',     label:'Match',      icon:'M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2M9 11a4 4 0 100-8 4 4 0 000 8zM23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75' },
    { href:'discover.html',  label:'Discover',   icon:'M11 19a8 8 0 100-16 8 8 0 000 16zM21 21l-4.35-4.35' },
    { href:'community.html', label:'Community',  icon:'M20 22v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2M12 12a4 4 0 100-8 4 4 0 000 8z' },
    { href:'spaces.html',    label:'My Spaces',  icon:'M3 9l9-7 9 7v11a1 1 0 01-1 1h-5v-7H9v7H4a1 1 0 01-1-1z' },
    { href:'friends.html',   label:'Friends',    icon:'M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2M9 11a4 4 0 100-8 4 4 0 000 8zM23 21v-2a4 4 0 00-3-3.87' },
    { href:'messages.html',  label:'Messages',   icon:'M21 11.5a8.4 8.4 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.4 8.4 0 01-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.4 8.4 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z' },
    { href:'profile.html',   label:'Profile',    icon:'M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2M12 11a4 4 0 100-8 4 4 0 000 8z' },
    { href:'settings.html',  label:'Settings',   icon:'M12 15a3 3 0 100-6 3 3 0 000 6z M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06A1.65 1.65 0 009 4.6a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z' }
  ];

  function currentFile(){
    const p = window.location.pathname.split('/').pop();
    return p || 'home.html';
  }

  function demoUser(){
    try{
      const raw = localStorage.getItem('matchy_demo_user');
      if(raw) return JSON.parse(raw);
    }catch(e){}
    return { name:'Amara Osei', username:'amara_o', avatar:'🦊' };
  }

  function mount(){
    const el = document.getElementById('sidebarMount');
    if(!el) return;
    const here = currentFile();
    const u = demoUser();
    el.outerHTML = `
    <aside class="sidebar">
      <div class="brand"><img src="matchy-main-logo.png" alt="Matchy"></div>
      <nav class="nav">
        ${NAV.map(n => `
          <a href="${n.href}" class="${n.href===here?'active':''}">
            <svg viewBox="0 0 24 24"><path d="${n.icon}"/></svg>
            <span class="label">${n.label}</span>
          </a>`).join('')}
      </nav>
      <div class="sidebar-user">
        <div class="avatar-chip">${u.avatar}</div>
        <div class="who"><b>${u.name}</b><span>@${u.username}</span></div>
      </div>
    </aside>`;
  }

  document.addEventListener('DOMContentLoaded', mount);
})();
